﻿document.addEventListener("DOMContentLoaded", function () {

    // =========================
    // MATCH PAIRS
    // =========================
    document.querySelectorAll(".match-form").forEach(form => {

        let selectedLeft = null;

        const leftItems = form.querySelectorAll(".left-item");
        const rightItems = form.querySelectorAll(".right-item");
        const svg = form.querySelector(".match-lines");

        let pairs = new Array(leftItems.length).fill(null);
        form._pairs = pairs;

        function drawLines() {
            svg.innerHTML = "";

            pairs.forEach((p, i) => {
                if (!p) return;

                const leftEl = leftItems[i];
                const rightEl = [...rightItems].find(r => r.dataset.value === p.rightValue);

                if (!rightEl) return;

                const leftRect = leftEl.getBoundingClientRect();
                const rightRect = rightEl.getBoundingClientRect();
                const parentRect = svg.getBoundingClientRect();

                const x1 = leftRect.right - parentRect.left;
                const y1 = leftRect.top + leftRect.height / 2 - parentRect.top;

                const x2 = rightRect.left - parentRect.left;
                const y2 = rightRect.top + rightRect.height / 2 - parentRect.top;

                const line = document.createElementNS("http://www.w3.org/2000/svg", "line");

                line.setAttribute("x1", x1);
                line.setAttribute("y1", y1);
                line.setAttribute("x2", x2);
                line.setAttribute("y2", y2);

                line.setAttribute("stroke", "#7c3aed");
                line.setAttribute("stroke-width", "2");

                svg.appendChild(line);
            });
        }

        // LEFT click
        leftItems.forEach(left => {
            left.addEventListener("click", () => {
                selectedLeft = left;

                leftItems.forEach(x => x.classList.remove("selected"));
                left.classList.add("selected");
            });
        });

        // RIGHT click
        rightItems.forEach(right => {
            right.addEventListener("click", () => {

                if (!selectedLeft) return;

                const leftIndex = parseInt(selectedLeft.dataset.index);

                // очистка попереднього використання right
                pairs.forEach((p, i) => {
                    if (p && p.rightValue === right.dataset.value) {
                        pairs[i] = null;
                        leftItems[i].classList.remove("selected-pair");
                    }
                });

                pairs[leftIndex] = {
                    leftIndex: leftIndex.toString(),
                    rightValue: right.dataset.value
                };

                selectedLeft.classList.remove("selected");
                selectedLeft.classList.add("selected-pair");

                right.classList.add("selected-pair");

                selectedLeft = null;

                drawLines();
            });
        });

    });

    // =========================
    // REORDER
    // =========================
    document.querySelectorAll(".reorder-list").forEach(list => {

        let draggedItem = null;

        list.querySelectorAll("li").forEach(item => {

            item.addEventListener("dragstart", () => {
                draggedItem = item;
            });

            item.addEventListener("dragover", (e) => {
                e.preventDefault();
            });

            item.addEventListener("drop", () => {
                if (draggedItem && draggedItem !== item) {

                    let tempHTML = item.innerHTML;
                    let tempIndex = item.dataset.index;

                    item.innerHTML = draggedItem.innerHTML;
                    item.dataset.index = draggedItem.dataset.index;

                    draggedItem.innerHTML = tempHTML;
                    draggedItem.dataset.index = tempIndex;
                }
            });

        });

    });

    // =========================
    // GLOBAL SUBMIT
    // =========================
    document.querySelectorAll(".task-form").forEach(form => {

        let attempts = form.classList.contains("match-form") ? null : 0;

        form.addEventListener("submit", async function (e) {
            e.preventDefault();

            const resultDiv = form.querySelector(".result");
            const button = form.querySelector(".check-btn");

            // очистка стилів
            form.querySelectorAll(".left-item, .right-item").forEach(el => {
                el.classList.remove("correct", "incorrect");
            });

            // =========================
            // MATCH PAIRS
            // =========================
            if (form.classList.contains("match-form")) {

                const pairs = form._pairs;

                if (!pairs || pairs.some(p => p === null)) {
                    alert("Зістав всі пари!");
                    return;
                }

                form.querySelector(".pairs-input").value = JSON.stringify(pairs);
            }

            // =========================
            // REORDER
            // =========================
            const reorderList = form.querySelector(".reorder-list");
            const orderInput = form.querySelector(".order-input");

            if (reorderList && orderInput) {
                const order = [];

                reorderList.querySelectorAll("li").forEach(li => {
                    order.push(li.dataset.index);
                });

                orderInput.value = order.join(",");
            }

            // =========================
            // MULTIPLE CHECK VALIDATION
            // =========================
            const checkboxes = form.querySelectorAll("input[name='selectedIndexes']");
            if (checkboxes.length > 0) {
                const checked = form.querySelectorAll("input[name='selectedIndexes']:checked");
                if (checked.length === 0) {
                    alert("Обери хоча б одну відповідь");
                    return;
                }
            }

            // =========================
            // SEND
            // =========================
            const formData = new FormData(form);

            // DEBUG (можеш прибрати)
            for (let pair of formData.entries()) {
                console.log(pair[0], pair[1]);
            }

            // CSRF
            const tokenInput = form.querySelector("input[name='__RequestVerificationToken']");
            const headers = tokenInput
                ? { "RequestVerificationToken": tokenInput.value }
                : {};

            const response = await fetch(form.action, {
                method: "POST",
                headers: headers,
                body: formData
            });

            if (!response.ok) {
                resultDiv.innerText = "❌ Помилка сервера";
                return;
            }

            const data = await response.json();

            // =========================
            // MATCH RESULT
            // =========================
            if (form.classList.contains("match-form")) {

                if (data.isCorrect) {
                    resultDiv.innerText = "✅ Правильно";

                    form.querySelectorAll(".selected-pair").forEach(el => {
                        el.classList.remove("selected-pair");
                        el.classList.add("correct");
                    });

                    button.disabled = true;
                } else {
                    resultDiv.innerText = "❌ Неправильно";

                    const pairs = form._pairs;

                    pairs.forEach((p, i) => {
                        if (!p) return;

                        const left = form.querySelector(`.left-item[data-index="${i}"]`);
                        const right = [...form.querySelectorAll(".right-item")]
                            .find(r => r.dataset.value === p.rightValue);

                        if (!left || !right) return;

                        if (left.innerText.trim() === right.innerText.trim()) {
                            left.classList.add("correct");
                            right.classList.add("correct");
                        } else {
                            left.classList.add("incorrect");
                            right.classList.add("incorrect");
                        }
                    });
                }

                return;
            }

            // =========================
            // OTHER TYPES
            // =========================
            if (attempts !== null) attempts++;

            if (data.isCorrect) {
                resultDiv.innerText = "✅ Правильно";
                button.disabled = true;
            } else {
                resultDiv.innerText = attempts !== null
                    ? `❌ Неправильно (${attempts}/2)`
                    : "❌ Неправильно";

                if (attempts >= 2) {
                    button.disabled = true;
                }
            }

        });

    });

});