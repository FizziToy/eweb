﻿using eweb.Domain.Entities.Exercises;

namespace eweb.Web.Models.Exercises;

public class ExerciseTaskCreateViewModel
    : BaseExerciseTaskViewModel
{
}